package bao;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import scs.SI;

@Controller
public class SiController {
	@RequestMapping("si")
	public ModelAndView siLoad()
	{
		return new ModelAndView("si","command",new SI());
	}
	@RequestMapping("silogic")
	public ModelAndView siLogic(@ModelAttribute("spring-mvc-example")SI s)
	{
		float res = (s.getP()*s.getR()*s.getT())/100;
		return new ModelAndView("siresult","key",res);
	}

}
